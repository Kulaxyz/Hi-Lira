<?php

return [
    'referal_bonus'  => 0.05
];
