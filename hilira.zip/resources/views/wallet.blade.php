<!DOCTYPE html>
<html>
@component('components.head')
@endcomponent

<body>

<!-- Site -->
<header class="header-lk header-home">
    <div class="container">
        @component('components.header_logo')
        @endcomponent
        <div class="row">
            <div class="col-12">
                <div class="profile">
                    <div class="profile__image">
                        <img src="/img/profile.png" alt="Profile img">
                    </div>
                    <div class="profile__id">
                        Benim ıd: {{$wallet}}
                    </div>
                    <div class="profile__balance">
                        <span>Benim denge: </span>
                        <h2 style="font-size: 22px !important;" id="current_balance">₺{{$balance}}</h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row pages-link">
            <div class="col-12 d-flex justify-content-center">
                <a class="fs" href="{{ route('invest') }}">
                    <p>Para yatırmak</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="{{ route('withdrawal') }}">
                    <img src="/img/money.svg" alt="money">
                    <p>Para Çekmek</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="{{ route('history') }}">
                    <img src="/img/refresh.svg" alt="refresh">
                    <p>işlem geçmişi</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="{{ route('referral') }}">
                    <img src="/img/hand.png" alt="hand">
                    <p>Arkadaşını Davet et</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="#">
                    <img src="/img/head.png" alt="head">
                    <p>‍Yardım</p>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <a  onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();" class="logout">
                    <img src="/img/logout.svg" alt="logout" width="16" height="16">
                    <span>Oturumu kapat</span>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                </a>
            </div>
        </div>
    </div>
</header>

@component('components.scripts')
@endcomponent
<script>
    let update_balance = function () {
        $.get('{{ route('get_balance') }}', function (new_balance) {
            let x = $('#current_balance').text();
            let current_balance = parseFloat(x.replace('₺', ''));

            if (current_balance != new_balance) {

                $('#current_balance').text('₺'+new_balance);
                $('#current_balance').animate({fontSize: 24}, 300);
                $('#current_balance').css({color: "#a5ff72"});
                $('#current_balance').animate({fontSize: 22}, 300);
                setTimeout(function () {
                    $('#current_balance').css('color', '#ffffff')
                }, 600)

            }
        });
    };

    $(document).ready(function () {
        setInterval(update_balance, 1000*6);
    })
</script>
</body>
</html>
