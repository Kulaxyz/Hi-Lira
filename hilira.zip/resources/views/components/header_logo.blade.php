<div class="row">
    <div class="col-12">
        <div class="header-sec__top-bar">
            <a href="{{ route('wallet') }}" class="header-sec__top-bar--logo">
                <img src="/img/logo.svg" alt="Logo">
            </a>
        </div>
    </div>
</div>
