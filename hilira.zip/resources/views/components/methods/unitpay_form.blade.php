<?php /* это метод оплаты UnitPay */ ?>
<li title="UnitPay" class="col-md-4 wow animated fadeIn" data-wow-delay="1.0s">
    <a href="#" class="method" onclick="event.preventDefault();unitpay('usd');">
        <span class="method-logo">
        	<img src="assets/images/methods/visa.png" alt="unitpay" style="#visibility: hidden;">
        </span>
    </a>
</li>