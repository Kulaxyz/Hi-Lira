<?php /* это метод оплаты coinpayments через ETH */ ?>
<li class="col-md-4 wow animated fadeIn" data-wow-delay="2.0s">
    <a href="#" class="method" onclick="event.preventDefault();
init('eth')">
        <span class="method-logo">
            <img src="assets/images/methods/ethereum.png" alt="">
        </span>
       <!--  <span class="method-rate">
            <span class="value">{{round($eth, 6)}}</span>
            <span class="currency">ETH</span>
        </span> -->
    </a>
</li>