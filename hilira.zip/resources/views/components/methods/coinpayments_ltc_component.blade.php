<?php /* это метод оплаты coinpayments через LTC */ ?>
<li class="col-md-4 wow animated fadeIn" data-wow-delay="1.8s">
    <a href="#" class="method" onclick="event.preventDefault();
init('ltc')">
        <span class="method-logo">
            <img src="assets/images/methods/litecoin.png" alt="">
        </span>
       <!--  <span class="method-rate">
            <span class="value">{{round($ltc, 6)}}</span>
            <span class="currency">LTC</span>
        </span> -->
    </a>
</li>