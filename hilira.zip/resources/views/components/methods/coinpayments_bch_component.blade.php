<?php /* это метод оплаты coinpayments через BCH */ ?>
<li class="col-md-4 wow animated fadeIn" data-wow-delay="2.2s">
    <a href="#" onclick="event.preventDefault();
init('bch')" class="method">
        <span class="method-logo">
            <img src="assets/images/methods/bitcoin-cash.png" alt="">
        </span>
       <!--  <span class="method-rate">
            <span class="value">{{round($bch, 6)}}</span>
            <span class="currency">BCH</span>
        </span> -->
    </a>
</li>