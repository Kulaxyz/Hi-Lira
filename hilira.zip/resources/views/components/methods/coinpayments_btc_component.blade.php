<?php /* это метод оплаты coinpayments через BTC */ ?>
<li class="col-md-4 wow animated fadeIn" data-wow-delay="1.6s">
    <a href="#" class="method" onclick="event.preventDefault();
init('btc')">
        <span class="method-logo">
            <img src="assets/images/methods/bitcoin.png" alt="">
        </span>
       <!--  <span class="method-rate">
            <span class="value">{{round($btc, 6)}}</span>
            <span class="currency">BTC</span>
        </span> -->
    </a>
</li>