    <footer>
        <div class="container">
            <div class="left">
                <div class="copyright">© 2019 Libra Association</div>
            </div>
            <div class="right">
                <ul class="links">
                    <li><a href="{{route('privacy')}}">Data Policy</a></li>
                    <li><a href="#">Cookies</a></li>
                    <li><a href="#">Terms of Use</a></li>
                    <li><a href="#">Affiliate program</a></li>
                </ul>
            </div>
        </div>
    </footer>