<footer class="footer">
    <h2>Halıcıoğlu, Sallabaş Sk. 4/1, 34445 Beyoğlu/İstanbul, Turkey</h2>
    <a href="mailto:info@lira.pw">info@lira.pw</a>
</footer>
