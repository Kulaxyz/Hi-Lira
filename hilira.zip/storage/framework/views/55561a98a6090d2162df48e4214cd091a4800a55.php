<!DOCTYPE html>
<html>
<?php $__env->startComponent('components.head'); ?>
<?php echo $__env->renderComponent(); ?>
<body>

<!-- Site -->
<header class="header-lk header-home">
    <div class="container">
        <?php $__env->startComponent('components.header_logo'); ?>
        <?php echo $__env->renderComponent(); ?>
        <div class="row">
            <div class="col-12">
                <div class="card-descr">
                    <h1>Coefficients, %</h1>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="color: red; margin: 40px; font-size: 30px"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <form action="<?php echo e(route('coefs')); ?>" method="post" class="card-form">
                    <?php echo csrf_field(); ?>
                    <label>
                        <p>Minimal Coefficient:</p>
                        <div class="card-form__item">
                            <input type="tel" name="min_coef" placeholder="Min Coefficient" value="<?php echo e($min); ?>" required>
                        </div>
                    </label>
                    <label>
                        <p>Maximum Coefficient:</p>
                        <div class="card-form__item">
                            <input type="tel" name="max_coef" placeholder="Max Coefficient" required value="<?php echo e($max); ?>">
                        </div>
                    </label>
                    <button type="submit">Save</button>
                </form>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="<?php echo e(route('wallet')); ?>" class="card-return">
                    <img src="/img/arr-wh.svg" alt="arrow">
                    <span>Geri dön</span>
                </a>
            </div>
        </div>
    </div>
</header>

<?php $__env->startComponent('components.scripts'); ?>
<?php echo $__env->renderComponent(); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\hilira\resources\views/coefs.blade.php ENDPATH**/ ?>