<!DOCTYPE html>
<html>
<?php $__env->startComponent('components.head'); ?>
<?php echo $__env->renderComponent(); ?>
<body>

<!-- Site -->
<header class="header-lk header-home">
    <div class="container">
        <?php $__env->startComponent('components.header_logo'); ?>
        <?php echo $__env->renderComponent(); ?>
        <div class="row">
            <div class="col-12">
                <div class="profile">
                    <div class="profile__balance">
                        <span>Benim denge: </span>
                        <h2>₺<?php echo e(auth()->user()->balance); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card-descr">
                    <p>Teslim süresi: 0-3 iş günü <b>Komisyon: 0%</b></p>
                    <p>İşlem başına minimum 100₺ Maksimum 8.000₺</p>
                    <p>Kart başına maksimum: günde 5 işlem, günde 23.500₺, ayda 44.000₺</p>
                    <?php if(isset($errors)): ?>
                        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p style="color: red; margin: 40px; font-size: 30px"><?php echo e($error); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <form action="<?php echo e(route('withdrawal')); ?>" method="post" class="card-form">
                    <?php echo csrf_field(); ?>
                    <div class="card-form__item">
                        <input id="card" type="tel" name="number" placeholder="Kart numarası" required>
                        <div class="cards-img">
                            <img src="/img/visa.png" alt="visamaster">
                        </div>
                    </div>
                    <div class="card-form__item">
                        <input id="cardTotal" type="tel" min="100" max="8000" name="amount" placeholder="Tutar" required>
                    </div>
                    <button class="grey-bg" id="cardBtn" type="submit" disabled>Para Çekmek</button>
                </form>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="<?php echo e(route('wallet')); ?>" class="card-return">
                    <img src="/img/arr-wh.svg" alt="arrow">
                    <span>Geri dön</span>
                </a>
            </div>
        </div>
    </div>
</header>

<?php $__env->startComponent('components.scripts'); ?>
<?php echo $__env->renderComponent(); ?>


</body>
</html>
<?php /**PATH C:\xampp\htdocs\hilira\resources\views/withdrawal.blade.php ENDPATH**/ ?>