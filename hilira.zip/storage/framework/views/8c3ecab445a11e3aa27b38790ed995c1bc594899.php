<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($title ?? 'Hi Lira'); ?></title>
    <link href="https://fonts.googleapis.com/css?family=IBM+Plex+Mono:400,500,600,700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="/img/favicon.png" type="image/png">
    <link rel="stylesheet" href="/css/animate.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Swiper/4.5.0/css/swiper.min.css">
    <link rel="stylesheet" href="/css/bootstrap-grid.min.css">
    <link rel="stylesheet" href="/css/bootstrap-reboot.css.map">
    <link rel="stylesheet" href="/css/style.css">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<?php /**PATH C:\xampp\htdocs\hilira\resources\views/components/head.blade.php ENDPATH**/ ?>