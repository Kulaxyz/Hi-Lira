<!doctype html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>FTF</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-grid.css">
    <link rel="stylesheet" type="text/css" href="css/jquery.fancybox.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/responsive.css">
    <!-- Yandex.Metrika counter -->
    <script type="text/javascript" >
        (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
            m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
        (window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");

        ym(56464744, "init", {
            clickmap:true,
            trackLinks:true,
            accurateTrackBounce:true,
            webvisor:true
        });
    </script>
    <noscript><div><img src="https://mc.yandex.ru/watch/56464744" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
    <!-- /Yandex.Metrika counter -->
</head>
<body>
<header>
    <div class="container d-flex align-items-center">
        <a href="<?php echo e(route('index')); ?>" class="logo"><img src="images/logo.svg" alt=""></a>
        <a href="<?php echo e(route('index')); ?>" class="tomain">Main</a>
    </div>
</header>
<div class="main_screen home_screen screen">
    <div class="wallet_icon">
        <img src="images/wallet_icon.svg" alt="">
    </div>
    <div class="main_screen_wallet"><span>Wallet: <?php echo e($wallet); ?></span></div>
    <div class="main_screen_balance d-flex align-items-end justify-content-center">
        <span>Balance:</span>
        <div>$ <?php echo e($coins); ?></div>
        <?php if($coins > 0): ?>
            <span class="pos-balance" style="color: #6BB441"></span>
            <img class="arrow-balance" src="/images/up-arrow.svg" alt="">
        <?php else: ?>
            <span class="pos-balance" style="color: #9c8f8f"> 0 daily</span>
            <img class="arrow-balance" src="/images/down-arrow.svg" alt="">
        <?php endif; ?>

    </div>
    <div class="main_screen_buttons">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <!-- Для неактивной кнопки депозита добавляется аттрибут disabled="disabled" -->
                    <a href="#" class="main_screen_buttons_item d-flex align-items-center justify-content-center deposit_button new_deposit_button">
                        <span>NEW Deposit</span>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#" class="main_screen_buttons_item d-flex align-items-center justify-content-center withdraw_button">
                        <img src="images/main_icon1.svg" alt="">
                        <span>Withdraw Funds</span>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#" class="main_screen_buttons_item d-flex align-items-center justify-content-center transaction_button">
                        <img src="images/main_icon2.svg" alt="">
                        <span>Transaction History</span>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#" class="main_screen_buttons_item d-flex align-items-center justify-content-center affiliate_button">
                        <img src="images/main_icon3.svg" alt="">
                        <span>Affiliate program</span>
                    </a>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="<?php echo e(route('reviews')); ?>" class="main_screen_buttons_item d-flex align-items-center justify-content-center">
                        <img src="images/main_icon4.svg" alt="">
                        <span>Reviews</span>
                    </a>
                </div>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-api')): ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="<?php echo e(route('api-keys')); ?>" class="main_screen_buttons_item d-flex align-items-center justify-content-center">
                        <img src="images/main_icon4.svg" alt="">
                        <span>API keys</span>
                    </a>
                </div>
                <?php endif; ?>
            </div>
            <div class="logout"><a href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log out</a></div>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;"><?php echo csrf_field(); ?></form>

        </div>
    </div>
</div>
<div class="main_screen transaction_history_screen  screen" style="display: none;">
    <div class="transaction_history">
        <div class="transaction_history_title">Transaction History</div>
        <div class="container">
            <div class="transaction_history_inner d-flex flex-column">
                <div class="transaction_history_inn">
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="transaction_history_item d-flex">
                        <div class="date"><?php echo e($transaction->created_at->toDayDateTimeString()); ?></div>
                        <div class="deposit">
                            <span class="green">Deposit</span>
                            <div><?php echo e($transaction->ammount_usd); ?> $</div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="transaction_history_item d-flex">
                            <span class="green">You have no transactions yet</span>
                        </div>
                    <?php endif; ?>
                </div>
                <a href="#" class="transaction_back d-flex align-items-center justify-content-center">
                    <svg width="11" height="8" viewBox="0 0 11 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M0.646446 3.64645C0.451184 3.84171 0.451184 4.15829 0.646446 4.35355L3.82843 7.53553C4.02369 7.7308 4.34027 7.7308 4.53553 7.53553C4.7308 7.34027 4.7308 7.02369 4.53553 6.82843L1.70711 4L4.53553 1.17157C4.7308 0.976311 4.7308 0.659728 4.53553 0.464466C4.34027 0.269204 4.02369 0.269204 3.82843 0.464466L0.646446 3.64645ZM11 3.5L1 3.5V4.5L11 4.5V3.5Z" fill="black"/>
                    </svg>
                    <span>Back</span>
                </a>
            </div>
        </div>
    </div>
</div>
<div class="inner_screen screen new_deposit_screen" style="display: none;">
    <div class="container d-flex flex-column">
        <div class="back_link">
            <a href="#">Enter Amount</a>
        </div>
        <div class="amount_block">
            <div class="amount_input">
                <form id="depositForm" action="<?php echo e(route('get')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input id="depositValue" name="value" required type="number" placeholder="$ 49 " class="input">
                </form>
                <div class="amount_input_text">min: 1$ max: 100,000$</div>
            </div>
            <!-- Для неактивной кнопки депозита добавляется аттрибут disabled="disabled" -->
            <a href="#" onclick="event.preventDefault(); submitDeposit()" class="amount_button">NEW Deposit</a>
        </div>
    </div>
</div>
<div class="inner_screen methods_screen screen withdraw_screen" style="display: none;">
    <div class="container d-flex flex-column">
        <div class="back_link">
            <a href="#">Methods</a>
        </div>
        <div class="methods_blocks">
            <div class="row">
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#cards_popup" class="methods_blocks_item d-flex align-items-center justify-content-center"><img src="images/cards.png" alt=""></a>
                    <div style="display: none">
                        <div class="methods_popup" id="cards_popup">
                            <div class="methods_popup_image d-flex justify-content-center align-items-center"><img src="images/cards.png" alt=""></div>
                            <form action="/">
                                <input type="text" placeholder="Enter your wallet number" class="methods_popup_input">
                                <div class="methods_popup_input_wrapper">
                                    <input type="text" placeholder="Amount" class="methods_popup_input">
                                    <div class="curr">$</div>
                                </div>
                                <button class="submit_button" type="submit">Withdraw funds</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#bitcoin_popup" class="methods_blocks_item d-flex align-items-center justify-content-center"><img src="images/bitcoin.png" alt=""></a>
                    <div style="display: none">
                        <div class="methods_popup" id="bitcoin_popup">
                            <div class="methods_popup_image d-flex justify-content-center align-items-center"><img src="images/bitcoin.png" alt=""></div>
                            <form action="/">
                                <input type="text" placeholder="Enter your wallet number" class="methods_popup_input">
                                <div class="methods_popup_input_wrapper">
                                    <input type="text" placeholder="Amount" class="methods_popup_input">
                                    <div class="curr">$</div>
                                </div>
                                <button class="submit_button" type="submit">Withdraw funds</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#bitcoincash_popup" class="methods_blocks_item d-flex align-items-center justify-content-center"><img src="images/bitcoin-cash.png" alt=""></a>
                    <div style="display: none">
                        <div class="methods_popup" id="bitcoincash_popup">
                            <div class="methods_popup_image d-flex justify-content-center align-items-center"><img src="images/bitcoin-cash.png" alt=""></div>
                            <form action="/">
                                <input type="text" placeholder="Enter your wallet number" class="methods_popup_input">
                                <div class="methods_popup_input_wrapper">
                                    <input type="text" placeholder="Amount" class="methods_popup_input">
                                    <div class="curr">$</div>
                                </div>
                                <button class="submit_button" type="submit">Withdraw funds</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#ethereum_popup" class="methods_blocks_item d-flex align-items-center justify-content-center"><img src="images/ethereum-logo.png" alt=""></a>
                    <div style="display: none">
                        <div class="methods_popup" id="ethereum_popup">
                            <div class="methods_popup_image d-flex justify-content-center align-items-center"><img src="images/ethereum-logo.png" alt=""></div>
                            <form action="/">
                                <input type="text" placeholder="Enter your wallet number" class="methods_popup_input">
                                <div class="methods_popup_input_wrapper">
                                    <input type="text" placeholder="Amount" class="methods_popup_input">
                                    <div class="curr">$</div>
                                </div>
                                <button class="submit_button" type="submit">Withdraw funds</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#litecoin_popup" class="methods_blocks_item d-flex align-items-center justify-content-center"><img src="images/litecoin.png" alt=""></a>
                    <div style="display: none">
                        <div class="methods_popup" id="litecoin_popup">
                            <div class="methods_popup_image d-flex justify-content-center align-items-center"><img src="images/litecoin.png" alt=""></div>
                            <form action="/">
                                <input type="text" placeholder="Enter your wallet number" class="methods_popup_input">
                                <div class="methods_popup_input_wrapper">
                                    <input type="text" placeholder="Amount" class="methods_popup_input">
                                    <div class="curr">$</div>
                                </div>
                                <button class="submit_button" type="submit">Withdraw funds</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="inner_screen affiliate_screen screen" style="display: none;">
    <div class="container d-flex flex-column">
        <div class="back_link">
            <a href="#">
                <img src="images/affiliate_icon.svg" alt="">
                <span>Affiliate program</span>
            </a>
        </div>
        <div class="affiliate_inner">
            <p>Every user of the  «FTF» Company can user their Affiliate Link to invite users and receive Comissions from their Deposits.</p>
            <p>Affiliate Comission: <span>5% from the deposit amount</span></p>
            <p><span>Example :</span> A person invested 20 000 $, You automatically receive 1000$ to your Balance.</p>
            <p><span>Please make sure to Follow the Affiliate Program Rules and dont register multiple accounts per user.</span></p>
        </div>
        <div class="affiliate_link">
            <div class="affiliate_link_title">Your Affiliate Link</div>
            <a href="<?php echo e(route('referalRegister', $wallet)); ?>" target="_blank"><?php echo e(route('referalRegister', $wallet)); ?></a>
            <div class="earnings">Your Earnings</div>
            <div class="count"><?php echo e($profit); ?> $</div>
        </div>
        <div class="affiliate_counts">
            <div class="row">
                <div class="col-4">
                    <div class="affiliate_counts_item">
                        <div>Total Affiliates:</div>
                        <?php echo e($total); ?>

                    </div>
                </div>
                <div class="col-4">
                    <div class="affiliate_counts_item">
                        <div>Active Affiliates</div>
                        <?php echo e($activeAffiliates); ?>

                    </div>
                </div>
                <div class="col-4">
                    <div class="affiliate_counts_item">
                        <div>Inactive Partners</div>
                        <?php echo e($inactiveAffiliates); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="js/jquery.fancybox.min.js"></script>
<script src="js/main.js"></script>
<script>
    $(document).ready(function () {
        let bal = <?php echo e($coins); ?>;
        if (bal > 0){
            let profit = bal * <?php echo e(0.012); ?>;
            $('.pos-balance').text('+' + profit + '$');
        }
    });
    function submitDeposit() {
        let str = $("#depositValue").val();
        if (str == '') {
            str = 49;
        }
        let value = parseInt(str, 10);
        $("#depositValue").val(value);
        $('#depositForm').submit();
    }

</script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hilira\resources\views/newcabinet.blade.php ENDPATH**/ ?>