<!DOCTYPE html>
<html>
<?php $__env->startComponent('components.head'); ?>
<?php echo $__env->renderComponent(); ?>
<body style="background: #000;">

<!-- Site -->
<header class="header-lk header-bc">
    <div class="container">
        <?php $__env->startComponent('components.header_logo'); ?>
        <?php echo $__env->renderComponent(); ?>
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <a href="<?php echo e(route('wallet')); ?>" class="return">
                    <img src="/img/arr-wh.svg" alt="arr">
                    <span>Işlem Geçmişi</span>
                </a>
            </div>
        </div>
    </div>
</header>

<section class="pays">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="pays__card">
                    <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pays__card--item">
                            <div class="date">
                                <?php echo e($transaction->created_at->toDayDateTimeString()); ?>

                            </div>
                            <div class="info">
                                <?php if($transaction->type == 'out'): ?>
                                <div class="status">Para Çekmek</div>
                                <?php else: ?>
                                    <div class="status">Para Yarıtmak</div>
                                <?php endif; ?>
                                <div class="price"><?php echo e($transaction->amount); ?> ₺</div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startComponent('components.scripts'); ?>
<?php echo $__env->renderComponent(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\hilira\resources\views/history.blade.php ENDPATH**/ ?>