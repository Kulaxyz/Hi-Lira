<!DOCTYPE html>
<html>
<?php $__env->startComponent('components.head'); ?>
<?php echo $__env->renderComponent(); ?>

<body>

<!-- Site -->
<header class="header-lk header-home">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="header-sec__top-bar">
                    <a href="/lk_home.html" class="header-sec__top-bar--logo">
                        <img src="/img/logo.svg" alt="Logo">
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="profile">
                    <div class="profile__image">
                        <img src="/img/profile.png" alt="Profile img">
                    </div>
                    <div class="profile__id">
                        Benim ıd: <?php echo e($wallet); ?>

                    </div>
                    <div class="profile__balance">
                        <span>Benim denge: </span>
                        <h2>₺<?php echo e($balance); ?></h2>
                    </div>
                </div>
            </div>
        </div>
        <div class="row pages-link">
            <div class="col-12 d-flex justify-content-center">
                <a class="fs" href="/lk_popolnenie.html">
                    <p>Para yatırmak</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="/lk_card.html">
                    <img src="/img/money.svg" alt="money">
                    <p>Para Çekmek</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="/lk_pays.html">
                    <img src="/img/refresh.svg" alt="refresh">
                    <p>işlem geçmişi</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="/lk_referals.html">
                    <img src="/img/hand.png" alt="hand">
                    <p>Arkadaşını Davet et</p>
                </a>
            </div>
            <div class="col-12 d-flex justify-content-center">
                <a href="#">
                    <img src="/img/head.png" alt="head">
                    <p>‍Yardım</p>
                </a>
            </div>
        </div>
        <div class="row">
            <div class="col-12 d-flex justify-content-center">
                <a  onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();" class="logout">
                    <img src="/img/logout.svg" alt="logout" width="16" height="16">
                    <span>Oturumu kapat</span>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </a>
            </div>
        </div>
    </div>
</header>

<?php $__env->startComponent('components.scripts'); ?>
<?php echo $__env->renderComponent(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\hilira\resources\views/home.blade.php ENDPATH**/ ?>